import numpy as np
from Optimization import Optimizers
from Layers import Base
import copy

class FullyConnected(Base.BaseLayer):
    def __init__(self, input_size, output_size):
        super().__init__()
        self.trainable = True
        self.input_size = input_size
        self.output_size = output_size
        
        # Initialize combined weights and bias matrix
        # Last row contains the bias terms
        self.weights = np.random.uniform(size=(input_size + 1, output_size))
        self.gradient_weights = None
        self._optimizer = None
        self.temp = []

    @property
    def optimizer(self):
        return self._optimizer

    @optimizer.setter
    def optimizer(self, optimizer):
        self._optimizer = optimizer
        self._optimizer.weight = copy.deepcopy(optimizer)

    def forward(self, input_tensor):
        self.lastIn = input_tensor
        # Add ones column for bias
        self.augmented_input = np.concatenate([input_tensor, np.ones((input_tensor.shape[0], 1))], axis=1)
        # Single matrix multiplication includes both weights and bias
        self.lastOut = np.dot(self.augmented_input, self.weights)
        return self.lastOut
     
    def backward(self, error_tensor):
        # Compute gradients for input (excluding bias part)
        dx = np.dot(error_tensor, self.weights[:-1, :].T)
        
        # Compute combined gradients for weights and bias
        dW = np.dot(self.augmented_input.T, error_tensor)
        
        if self._optimizer is not None:
            self.weights = self._optimizer.weight.calculate_update(self.weights, dW)
        
        self.gradient_weights = dW
        return dx

    def initialize(self, weights_initializer, bias_initializer):
        # Initialize weights (excluding bias)
        weights = weights_initializer.initialize(
            (self.input_size, self.output_size), 
            self.input_size, 
            self.output_size
        )
        
        # Initialize bias
        bias = bias_initializer.initialize(
            (1, self.output_size), 
            1, 
            self.output_size
        )
        
        # Combine weights and bias into single matrix
        self.weights = np.vstack([weights, bias])