import numpy as np
import matplotlib.pyplot as plt

class Checker:
    def __init__(self, resolution, tile_size):
        """
        Initialize a checkerboard pattern generator
        
        Parameters:
        resolution (int): Number of pixels in each dimension
        tile_size (int): Number of pixels per tile in each dimension
        """
      
        assert resolution % (2 * tile_size) == 0
        
        self.resolution = resolution
        self.tile_size = tile_size
        self.output = None
        
    def draw(self):
        """Create a checkerboard pattern using NumPy operations"""
        basic_pattern = np.zeros((2, 2))
        basic_pattern[0, 1] = 1
        basic_pattern[1, 0] = 1
        
        tiled_basic = np.kron(basic_pattern, np.ones((self.tile_size, self.tile_size)))
        
        tiles_needed = self.resolution // (2 * self.tile_size)
        self.output = np.tile(tiled_basic, (tiles_needed, tiles_needed))
        
        return self.output.copy()
    
    def show(self):
        """Display the checkerboard pattern"""
        if self.output is None:
            self.draw()
        plt.figure(figsize=(8, 8))
        plt.imshow(self.output, cmap='gray')
        plt.title("Checkerboard Pattern")
        plt.show()

class Circle:
    def __init__(self, resolution, radius, position):
        """
        Initialize a binary circle pattern generator
        
        Parameters:
        resolution (int): Number of pixels in each dimension
        radius (int): Radius of the circle
        position (tuple): (x, y) coordinates of the circle's center
        """
        self.resolution = resolution
        self.radius = radius
        self.position = position
        self.output = None
        
    def draw(self):
        """Create a binary circle pattern using NumPy operations"""
        # Create coordinate grids
        y, x = np.ogrid[:self.resolution, :self.resolution]
        
        # Calculate distance from center for each pixel
        # Note: position is (x, y), but array indices are [y, x]
        center_x, center_y = self.position
        dist_squared = (x - center_x)**2 + (y - center_y)**2
        
        # Create binary mask where circle should be
        self.output = np.zeros((self.resolution, self.resolution))
        self.output[dist_squared <= self.radius**2] = 1
        
        # Return a copy
        return self.output.copy()
    
    def show(self):
        """Display the circle pattern"""
        if self.output is None:
            self.draw()
        plt.figure(figsize=(8, 8))
        plt.imshow(self.output, cmap='gray')
        plt.title("Binary Circle Pattern")
        plt.show()

class Spectrum:
    def __init__(self, resolution):
        """
        Initialize an RGB color spectrum generator
        
        Parameters:
        resolution (int): Number of pixels in each dimension
        """
        self.resolution = resolution
        self.output = None
        
    def draw(self):
        """Create an RGB color spectrum using NumPy operations"""
        x = np.linspace(0, 1, self.resolution)
        X = np.tile(x,self.resolution).reshape(self.resolution,self.resolution)
      
        self.output = np.zeros((self.resolution, self.resolution, 3))
        self.output[:, :, 0] = X
        self.output[:, :, 1] = np.transpose(X)
        self.output[:, :, 2] = np.flip(X,1)
    
        return self.output.copy()
    
    def show(self):
        """Display the RGB spectrum"""
        if self.output is None:
            self.draw()
        plt.figure(figsize=(8, 8))
        plt.imshow(self.output)
        plt.title("RGB Color Spectrum")
        plt.show()



def main():
    checker = Checker(resolution=512, tile_size=64)
    checker.draw()
    checker.show()
    
    circle = Circle(resolution=512, radius=100, position=(256, 256))
    circle.draw()
    circle.show()
    
    spectrum = Spectrum(resolution=1024)
    spectrum.draw()
    spectrum.show()

if __name__ == "__main__":
    main()
