import numpy as np
import matplotlib.pyplot as plt

from pattern import  Checker, Circle, Spectrum
