import os.path
import json
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import zoom 

class ImageGenerator:
    def __init__(self, file_path, label_path, batch_size, image_size, rotation=False, mirroring=False, shuffle=False):
        
        self.file_path = file_path
        self.batch_size = batch_size
        self.image_size = image_size  
        self.rotation = rotation
        self.mirroring = mirroring
        self.shuffle = shuffle
        
        self.class_dict = {0: 'airplane', 1: 'automobile', 2: 'bird', 3: 'cat', 4: 'deer', 5: 'dog', 6: 'frog',
                           7: 'horse', 8: 'ship', 9: 'truck'}
        
        with open(label_path, 'r') as f:
            self.labels = json.load(f)
        
        self.image_files = [f for f in os.listdir(file_path) if f.endswith('.npy')]
        
        self.indices = np.arange(len(self.image_files))
        if self.shuffle:
            np.random.shuffle(self.indices)
        
        self.current_position = 0
        self.epoch_count = 0

    def next(self):

        images = np.zeros((self.batch_size, self.image_size[0], self.image_size[1], self.image_size[2]))
        labels = np.zeros(self.batch_size, dtype=int)
        
        for i in range(self.batch_size):

            if self.current_position >= len(self.indices):
                self.current_position = 0
                self.epoch_count += 1
                if self.shuffle:
                    np.random.shuffle(self.indices)
            

            idx = self.indices[self.current_position]
            img_file = self.image_files[idx]
            

            img_path = os.path.join(self.file_path, img_file)
            img = np.load(img_path)
            

            img = self.resize_image(img)
            

            img = self.augment(img)
            

            file_id = img_file.split('.')[0]
            label = self.labels[file_id]
            

            images[i] = img
            labels[i] = label
            

            self.current_position += 1
        
        return images, labels

    def resize_image(self, img):
        """Resize image to target size using scipy.ndimage.zoom"""

        target_h, target_w, target_c = self.image_size
        orig_h, orig_w = img.shape[0], img.shape[1]
        

        if len(img.shape) == 3:
            orig_c = img.shape[2]
            zoom_factors = (target_h/orig_h, target_w/orig_w, target_c/orig_c)
        else:

            img = img.reshape(orig_h, orig_w, 1)
            zoom_factors = (target_h/orig_h, target_w/orig_w, 1)
        

        resized_img = zoom(img, zoom_factors, order=1)
        
        return resized_img

    def augment(self, img):

        if self.rotation:

            k = np.random.choice([1, 2, 3])
            img = np.rot90(img, k=k)
        

        if self.mirroring and np.random.random() > 0.5:
            img = np.fliplr(img)
        
        return img

    def current_epoch(self):
        return self.epoch_count

    def class_name(self, x):
        return self.class_dict.get(x, "Unknown")
    
    def show(self):

        images, labels = self.next()
        

        fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(15, 6))
        axes = axes.flatten()
        

        num_imgs_to_show = min(10, self.batch_size)
        
        for i in range(num_imgs_to_show):
            if images[i].shape[-1] == 1: 
                axes[i].imshow(images[i].squeeze(), cmap='gray')
            else: 
                axes[i].imshow(images[i].astype(np.uint8))
            axes[i].set_title(f"Class: {self.class_name(labels[i])}")
            axes[i].axis('off')
        

        for i in range(num_imgs_to_show, 10):
            axes[i].axis('off')
        
        plt.tight_layout()
        plt.show()